Asteroids built using a from scratch C++ engine.
SDL2 used for rendering.

Controls
Move Forward: 	W
Move Back: 	S
Rotate:		A/D
Fire:		Space
Pause: 		Escape

Objective
Clear the asteroids